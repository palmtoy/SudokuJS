#Sudoku JS License

License for the Javascript and PHP Code: BSD

License for the Sudoku Puzzles:
* Free to use the 80 puzzles(10 in each level)
* Commercial license is required for the 1600 puzzles